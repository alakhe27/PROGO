PROG5121 QuickChat Java conversion
==================================

This project converts the uploaded C#-style Part 2 files into Java.

Files:
- src/main/java/Login.java: Java login/registration class based on your Part 1.
- src/main/java/Message.java: Java message validation, hash and action class.
- src/main/java/MessageManager.java: arrays/lists, JSON storage, searching, deletion and report.
- src/main/java/Main.java: console application and Stored Messages menu.
- src/test/java: JUnit 4 tests.

Open as a Maven project in NetBeans (File > Open Project), then run Main.java.
Run tests using the project's Test command.

Notes:
- The original program.cs.java and messageTests.cs.java contained C# syntax despite their .java-like filenames.
- The uploaded Message class also contained C# syntax and System.Text.Json, so it was rewritten in Java.
- This is a standalone Java reconstruction using the supplied Part 1 Login class. It is a working base, but compare the final behaviour with every requirement in your full POE document before submission.
- Stored messages are written to stored_messages.json in the application's working directory.
