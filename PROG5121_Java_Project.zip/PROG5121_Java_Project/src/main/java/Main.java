import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();

        System.out.println("=== USER REGISTRATION ===");
        System.out.print("First name: ");
        login.setFirstName(input.nextLine());
        System.out.print("Last name: ");
        login.setLastName(input.nextLine());

        String username, password, phone;
        do {
            System.out.print("Username (must contain _ and be max 5 characters): ");
            username = input.nextLine();
            if (!login.checkUserName(username)) System.out.println("Invalid username.");
        } while (!login.checkUserName(username));

        do {
            System.out.print("Password (8+ characters, uppercase, number and special character): ");
            password = input.nextLine();
            if (!login.checkPasswordComplexity(password)) System.out.println("Invalid password.");
        } while (!login.checkPasswordComplexity(password));

        do {
            System.out.print("Cell number (+27 followed by 9 digits): ");
            phone = input.nextLine();
            if (!login.checkCellPhoneNumber(phone)) System.out.println("Invalid cell number.");
        } while (!login.checkCellPhoneNumber(phone));

        System.out.println(login.registerUser(username, password, phone));
        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.println("\n=== USER LOGIN ===");
            System.out.print("Username: ");
            String u = input.nextLine();
            System.out.print("Password: ");
            String p = input.nextLine();
            loggedIn = login.loginUser(u, p);
            System.out.println(login.returnLoginStatus(loggedIn));
        }

        MessageManager manager = new MessageManager();
        manager.loadStoredMessages();
        System.out.println("\nWelcome to QuickChat.");

        boolean running = true;
        while (running) {
            System.out.println("\n--- QuickChat Menu ---");
            System.out.println("1) Send Messages");
            System.out.println("2) Show sent messages");
            System.out.println("3) Stored Messages");
            System.out.println("4) Load assignment test data");
            System.out.println("5) Quit");
            System.out.print("Choose: ");
            String choice = input.nextLine();

            switch (choice) {
                case "1": sendMessages(input, manager); break;
                case "2":
                    if (manager.getSentMessages().isEmpty()) System.out.println("No sent messages.");
                    else for (Message m : manager.getSentMessages())
                        System.out.println(m.getRecipientCell() + " | " + m.getMessageText());
                    break;
                case "3": storedMenu(input, manager); break;
                case "4":
                    manager.loadAssignmentTestData();
                    System.out.println("Assignment test data loaded.");
                    break;
                case "5": running = false; System.out.println("Goodbye."); break;
                default: System.out.println("Invalid option.");
            }
        }
        input.close();
    }

    private static void sendMessages(Scanner input, MessageManager manager) {
        System.out.print("How many messages? ");
        int count;
        try { count = Integer.parseInt(input.nextLine()); }
        catch (NumberFormatException e) { System.out.println("Enter a valid number."); return; }

        for (int i = 0; i < count; i++) {
            System.out.println("\nMessage " + (i + 1));
            System.out.print("Message ID (max 10 characters): ");
            String id = input.nextLine();
            System.out.print("Recipient (+27 followed by 9 digits): ");
            String recipient = input.nextLine();
            System.out.print("Message (max 250 characters): ");
            String text = input.nextLine();

            Message message = new Message(id, recipient, text);
            if (!message.checkMessageID() || !message.checkCharacterLimit()
                    || !message.checkRecipientCell().startsWith("Cell phone number successfully")) {
                System.out.println("Invalid message ID, message length, or recipient number. Try this message again.");
                i--;
                continue;
            }

            System.out.println("Message hash: " + message.getMessageHash());
            System.out.println("1) Send  2) Disregard  3) Store");
            int action;
            try { action = Integer.parseInt(input.nextLine()); }
            catch (NumberFormatException e) { System.out.println("Invalid choice."); i--; continue; }
            if (action < 1 || action > 3) { System.out.println("Invalid choice."); i--; continue; }
            manager.addMessage(message, action);
            System.out.println(message.SentMessage(action));
        }
    }

    private static void storedMenu(Scanner input, MessageManager manager) {
        boolean back = false;
        while (!back) {
            System.out.println("\n--- Stored Messages ---");
            System.out.println("1) Display sender and recipient");
            System.out.println("2) Display longest stored message");
            System.out.println("3) Search by message ID");
            System.out.println("4) Search by recipient");
            System.out.println("5) Delete by message hash");
            System.out.println("6) Display full report");
            System.out.println("7) Back to main menu");
            System.out.print("Choose: ");
            String option = input.nextLine();
            switch (option) {
                case "1":
                    System.out.print(manager.displayStoredSendersAndRecipients("Current user"));
                    break;
                case "2":
                    Message longest = manager.getLongestStoredMessage();
                    System.out.println(longest == null ? "No stored messages." : longest.getMessageText());
                    break;
                case "3":
                    System.out.print("Message ID: ");
                    Message found = manager.findByMessageID(input.nextLine());
                    System.out.println(found == null ? "Message not found."
                            : "Recipient: " + found.getRecipientCell() + "\nMessage: " + found.getMessageText());
                    break;
                case "4":
                    System.out.print("Recipient number: ");
                    List<Message> matches = manager.findByRecipient(input.nextLine());
                    if (matches.isEmpty()) System.out.println("No messages found.");
                    for (Message m : matches) System.out.println(m.getMessageText());
                    break;
                case "5":
                    System.out.print("Message hash: ");
                    System.out.println(manager.deleteByHash(input.nextLine()) ? "Message deleted." : "Message hash not found.");
                    break;
                case "6": System.out.println(manager.displayReport()); break;
                case "7": back = true; break;
                default: System.out.println("Invalid option.");
            }
        }
    }
}
