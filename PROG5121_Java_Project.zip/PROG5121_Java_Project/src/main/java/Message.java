public class Message {
    private final String messageID;
    private final String recipientCell;
    private final String messageText;
    private final String messageHash;
    private int messageStatus; // 1 = sent, 2 = disregarded, 3 = stored

    public Message(String id, String cell, String text) {
        this.messageID = id == null ? "" : id;
        this.recipientCell = cell == null ? "" : cell;
        this.messageText = text == null ? "" : text;
        this.messageHash = createMessageHash();
    }

    public boolean checkMessageID() {
        return !messageID.isEmpty() && messageID.length() <= 10;
    }

    public boolean checkCharacterLimit() {
        return !messageText.isEmpty() && messageText.length() <= 250;
    }

    public String checkRecipientCell() {
        // South African international format: +27 followed by 9 digits.
        return recipientCell.matches("^\\+27\\d{9}$")
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+");
        String first = words.length == 0 || words[0].isEmpty() ? "" : words[0].replaceAll("[^A-Za-z0-9]", "").toUpperCase();
        String last = words.length == 0 || words[words.length - 1].isEmpty() ? first
                : words[words.length - 1].replaceAll("[^A-Za-z0-9]", "").toUpperCase();
        String idPart = messageID.length() >= 2 ? messageID.substring(0, 2) : messageID;
        return idPart + ":0:" + first + last;
    }

    public String SentMessage(int choice) {
        this.messageStatus = choice;
        switch (choice) {
            case 1: return "Message successfully sent.";
            case 2: return "Message disregarded.";
            case 3: return "Message successfully stored.";
            default: return "Invalid selection.";
        }
    }

    public String storeMessage() {
        return "{\"messageID\":\"" + escape(messageID) + "\","
                + "\"recipient\":\"" + escape(recipientCell) + "\","
                + "\"message\":\"" + escape(messageText) + "\","
                + "\"messageHash\":\"" + escape(messageHash) + "\","
                + "\"status\":" + messageStatus + "}";
    }

    private String escape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r");
    }

    public String getMessageID() { return messageID; }
    public String getRecipientCell() { return recipientCell; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
    public int getMessageStatus() { return messageStatus; }
}
