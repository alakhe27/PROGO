import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MessageManager {
    private final List<Message> sentMessages = new ArrayList<>();
    private final List<Message> disregardedMessages = new ArrayList<>();
    private final List<Message> storedMessages = new ArrayList<>();
    private final List<String> messageHashes = new ArrayList<>();
    private final List<String> messageIDs = new ArrayList<>();
    private final Path jsonFile = Path.of("stored_messages.json");

    public void addMessage(Message message, int action) {
        message.SentMessage(action);
        if (action == 1) sentMessages.add(message);
        else if (action == 2) disregardedMessages.add(message);
        else if (action == 3) {
            storedMessages.add(message);
            saveStoredMessages();
        }
        messageHashes.add(message.getMessageHash());
        messageIDs.add(message.getMessageID());
    }

    public List<Message> getSentMessages() { return sentMessages; }
    public List<Message> getDisregardedMessages() { return disregardedMessages; }
    public List<Message> getStoredMessages() { return storedMessages; }
    public List<String> getMessageHashes() { return messageHashes; }
    public List<String> getMessageIDs() { return messageIDs; }

    public String displayStoredSendersAndRecipients(String sender) {
        if (storedMessages.isEmpty()) return "No stored messages.";
        StringBuilder out = new StringBuilder();
        for (Message m : storedMessages)
            out.append("Sender: ").append(sender).append(" | Recipient: ")
               .append(m.getRecipientCell()).append(System.lineSeparator());
        return out.toString();
    }

    public Message getLongestStoredMessage() {
        Message longest = null;
        for (Message m : storedMessages)
            if (longest == null || m.getMessageText().length() > longest.getMessageText().length()) longest = m;
        return longest;
    }

    public Message findByMessageID(String id) {
        for (Message m : storedMessages) if (m.getMessageID().equals(id)) return m;
        return null;
    }

    public List<Message> findByRecipient(String recipient) {
        List<Message> matches = new ArrayList<>();
        for (Message m : storedMessages)
            if (m.getRecipientCell().equals(recipient)) matches.add(m);
        return matches;
    }

    public boolean deleteByHash(String hash) {
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedMessages.get(i).getMessageHash().equals(hash)) {
                storedMessages.remove(i);
                saveStoredMessages();
                return true;
            }
        }
        return false;
    }

    public String displayReport() {
        if (storedMessages.isEmpty()) return "No stored messages.";
        StringBuilder out = new StringBuilder("STORED MESSAGE REPORT\n");
        for (Message m : storedMessages) {
            out.append("Message ID: ").append(m.getMessageID()).append('\n')
               .append("Recipient: ").append(m.getRecipientCell()).append('\n')
               .append("Message: ").append(m.getMessageText()).append('\n')
               .append("Message Hash: ").append(m.getMessageHash()).append("\n\n");
        }
        return out.toString();
    }

    public void saveStoredMessages() {
        StringBuilder json = new StringBuilder("[\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            json.append("  ").append(storedMessages.get(i).storeMessage());
            if (i < storedMessages.size() - 1) json.append(",");
            json.append("\n");
        }
        json.append("]\n");
        try {
            Files.writeString(jsonFile, json.toString(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.out.println("Could not save stored messages: " + e.getMessage());
        }
    }

    // Reads the JSON file written by this application and restores stored messages.
    public void loadStoredMessages() {
        if (!Files.exists(jsonFile)) return;
        try {
            String json = Files.readString(jsonFile, StandardCharsets.UTF_8);
            Matcher objects = Pattern.compile("\\{([^}]*)\\}").matcher(json);
            while (objects.find()) {
                String object = objects.group(1);
                String id = field(object, "messageID");
                String recipient = field(object, "recipient");
                String text = field(object, "message");
                if (!id.isEmpty()) {
                    Message m = new Message(id, recipient, text);
                    m.SentMessage(3);
                    storedMessages.add(m);
                    messageIDs.add(id);
                    messageHashes.add(m.getMessageHash());
                }
            }
        } catch (IOException e) {
            System.out.println("Could not read stored messages: " + e.getMessage());
        }
    }

    private String field(String object, String key) {
        Matcher m = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"").matcher(object);
        if (!m.find()) return "";
        return m.group(1).replace("\\n", "\n").replace("\\r", "\r")
                .replace("\\\"", "\"").replace("\\\\", "\\");
    }

    // Assignment sample data: sent, stored, disregarded, sent, stored.
    public void loadAssignmentTestData() {
        addMessage(new Message("MSG001", "+27834557896", "Did you get the cake?"), 1);
        addMessage(new Message("MSG002", "+27838884567", "Where are you? You are late! I have asked you to be on time."), 3);
        addMessage(new Message("MSG003", "+27834484567", "Yohoooo, I am at your gate."), 2);
        addMessage(new Message("MSG004", "+27838884567", "It is dinner time !"), 1);
        addMessage(new Message("MSG005", "+27838884567", "Ok, I am leaving without you."), 3);
    }
}
