import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {
    private Login login;
    @Before public void setUp() {
        login = new Login("Kyle", "kn", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
    }
    @Test public void testUsernameCorrectlyFormattedMessage() {
        assertEquals("Welcome Kyle ,kn it is great to see you.", login.returnLoginStatus(true));
    }
    @Test public void testUsernameIncorrectlyFormattedMessage() {
        assertTrue(login.registerUser("kyle!!!!!!", "Ch&&sec@ke99!", "+27838968976").startsWith("Username is not correctly formatted"));
    }
    @Test public void testPasswordMeetsComplexity() {
        assertTrue(login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976").contains("Password successfully captured."));
    }
    @Test public void testPasswordDoesNotMeetComplexity() {
        assertTrue(login.registerUser("kyl_1", "password", "+27838968976").startsWith("Password is not correctly formatted"));
    }
    @Test public void testCellPhoneNumberCorrectlyFormatted() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }
    @Test public void testCellPhoneNumberIncorrectlyFormatted() {
        assertFalse(login.checkCellPhoneNumber("08966553"));
    }
    @Test public void testLoginSuccessful() {
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }
    @Test public void testLoginFailed() {
        assertFalse(login.loginUser("wrong_user", "wrong_pass"));
    }
}
