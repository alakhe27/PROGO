import org.junit.Test;
import static org.junit.Assert.*;

public class MessageManagerTests {
    @Test public void testStoredMessageSearchByID() {
        MessageManager manager = new MessageManager();
        manager.addMessage(new Message("ID001", "+27838884567", "Stored test message"), 3);
        assertNotNull(manager.findByMessageID("ID001"));
    }
    @Test public void testSearchByRecipient() {
        MessageManager manager = new MessageManager();
        manager.addMessage(new Message("ID001", "+27838884567", "First"), 3);
        manager.addMessage(new Message("ID002", "+27838884567", "Second"), 3);
        assertEquals(2, manager.findByRecipient("+27838884567").size());
    }
    @Test public void testDeleteByHash() {
        MessageManager manager = new MessageManager();
        Message m = new Message("ID001", "+27838884567", "Delete this");
        manager.addMessage(m, 3);
        assertTrue(manager.deleteByHash(m.getMessageHash()));
        assertNull(manager.findByMessageID("ID001"));
    }
    @Test public void testLongestStoredMessage() {
        MessageManager manager = new MessageManager();
        manager.addMessage(new Message("ID001", "+27838884567", "Short"), 3);
        manager.addMessage(new Message("ID002", "+27838884567", "This is the longest stored message"), 3);
        assertEquals("This is the longest stored message",
                manager.getLongestStoredMessage().getMessageText());
    }
}
