import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTests {
    @Test public void testMessageIDSuccess() {
        assertTrue(new Message("00", "+27718693002", "Test message").checkMessageID());
    }
    @Test public void testMessageIDFailure() {
        assertFalse(new Message("1234567891011", "+27718693002", "Test message").checkMessageID());
    }
    @Test public void testCharacterLimitSuccess() {
        assertTrue(new Message("00", "+27718693002", "Hi Mike, can you join us for dinner tonight?").checkCharacterLimit());
    }
    @Test public void testRecipientCellSuccess() {
        assertEquals("Cell phone number successfully captured.",
                new Message("00", "+27718693002", "Hello").checkRecipientCell());
    }
    @Test public void testRecipientCellFailure() {
        assertTrue(new Message("00", "08575975889", "Hello").checkRecipientCell().contains("incorrectly formatted"));
    }
    @Test public void testMessageHashGeneration() {
        assertEquals("00:0:HIMIKE", new Message("00", "+27718693002", "Hi Mike").createMessageHash());
    }
    @Test public void testSentMessageOptions() {
        Message m = new Message("00", "+27718693002", "Test");
        assertEquals("Message successfully sent.", m.SentMessage(1));
        assertEquals("Message disregarded.", m.SentMessage(2));
        assertEquals("Message successfully stored.", m.SentMessage(3));
    }
}
